def confuse (m,n):  # procedimiento confuso
  n = 1
  n = m + n
  
i = 4
confuse(i,i)
print i
